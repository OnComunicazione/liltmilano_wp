<?php

return array(
    'conditional_logic' => array(
        'id' => 'conditional_logic',
        'label' => __( 'Conditional Logic', 'ninja-forms-conditional-logic' ),
        'priority' => 800
    ),
);
